package com.example.newactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import android.widget.ImageView


class PicActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pic_layout)

        val imageView = findViewById<ImageView>(R.id.picView)

        val picUrl = intent.getStringExtra("picLink")
        Glide.with(this).load(picUrl).into(imageView)
    }
}