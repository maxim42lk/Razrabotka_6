package com.example.newactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn_show_pic = findViewById<Button>(R.id.btn_show_pic)
        btn_show_pic.setOnClickListener() {
            val intent = Intent(this, PicActivity::class.java)
            intent.putExtra("picLink", "https://get.wallhere.com/photo/lake-hills-mountains-flowers-plants-water-clouds-nature-landscape-bridge-wood-blue-1689357.jpg")
            startActivity(intent)
        }
    }
}